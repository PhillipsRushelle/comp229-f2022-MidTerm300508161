module.exports = {
  //local MongoDB deployment ->
  


  "URI" :"mongodb+srv://Rushelle:OoY3ML4hmtgN9C6d@mongodbsever.flce7dc.mongodb.net/?retryWrites=true&w=majority"

};



